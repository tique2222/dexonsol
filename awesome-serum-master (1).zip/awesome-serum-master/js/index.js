const APPS = require('./app-list.json');

module.exports = APPS;
